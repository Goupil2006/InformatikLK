package OOP.Stack;

public class Stack {
    Element head = null;

    public Stack() {

    }

    public void push(Element element) {
        element.setNext(head);
        head = element;
    }

    public Element pop() {
        Element element = head;
        head = head.getNext();
        return element;
    }

    public Element top() {
        return head;
    }

    public boolean isEmpty() {
        return head == null;
    }
}
